Metatag: Verification
---------------------
This module adds meta tags used to confirm ownership of the site with various
search engines and online services.


Usage
------------------------------------------------------------------------------
These tags are only available on the Global configuration section of the main
settings interface at admin/config/search/metatag as they affect the site as a
whole rather than portions of it.


Credits
------------------------------------------------------------------------------
Development and maintenance by Damien McKenna.
